#!/bin/bash



playerctl metadata --format '󰎈 {{title}} - {{artist}}'
