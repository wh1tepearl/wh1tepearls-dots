#!/bin/bash

cd ~/.config/waybar/

mv style1.css style-temp.css
mv style.css style1.css
mv style-temp.css style.css

killall waybar >/dev/null 2>&1
waybar >/dev/null 2>&1 &
disown

notify-send "Waybar" "Background toggled" --icon=preferences-system
