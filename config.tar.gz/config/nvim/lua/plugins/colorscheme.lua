return {
  {
    "nyoom-engineering/oxocarbon.nvim",
    lazy = false,
    priority = 1000,
    config = function()
      -- Включаем полную прозрачность
      vim.g.oxocarbon_transparent = true
      vim.opt.background = "dark"

      -- Применяем тему
      vim.cmd.colorscheme("oxocarbon")

      -- Делаем ВСЕ элементы прозрачными
      local transparent_groups = {
        "Normal",
        "NormalFloat",
        "NormalNC",
        "SignColumn",
        "LineNr",
        "CursorLine",
        "CursorLineNr",
        "StatusLine",
        "StatusLineNC",
        "EndOfBuffer",
        "Pmenu",
        "PmenuSel",
        "TelescopeNormal",
        "TelescopeBorder",
        "FloatBorder",
        "WhichKeyFloat",
      }

      for _, group in ipairs(transparent_groups) do
        vim.api.nvim_set_hl(0, group, { bg = "none" })
      end

      -- Настройки для Neo-tree/Explorer
      vim.api.nvim_set_hl(0, "NeoTreeNormal", { bg = "none" })
      vim.api.nvim_set_hl(0, "NeoTreeNormalNC", { bg = "none" })
      vim.api.nvim_set_hl(0, "NeoTreeEndOfBuffer", { bg = "none" })
      vim.api.nvim_set_hl(0, "DashboardHeader", { bg = "none" })
      vim.api.nvim_set_hl(0, "DashboardFooter", { bg = "none" })

      -- Защита от перезаписи
      vim.api.nvim_create_autocmd("ColorScheme", {
        pattern = "oxocarbon",
        callback = function()
          for _, group in ipairs(transparent_groups) do
            vim.api.nvim_set_hl(0, group, { bg = "none" })
          end
        end,
      })
    end,
  },
}
