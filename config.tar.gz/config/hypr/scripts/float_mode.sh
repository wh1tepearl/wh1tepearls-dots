#!/bin/bash

cd ~/.config/hypr/

mv hyprland1.conf hyprland-temp.conf
mv hyprland.conf hyprland1.conf
mv hyprland-temp.conf hyprland.conf

hyprctl reload

#notify-send "Hyprland" "Float mode toggled" --icon=preferences-system
