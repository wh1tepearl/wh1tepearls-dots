#!/bin/bash

#SETTINGS

echo "1. Toggle float mode (hyprland)"
echo "2. Change waybar style (waybar)"
echo "3. Quit"

echo "Chose an option (1 - 3)"
read -p ">>> " option_chosed

if [[ "$option_chosed" =~ "1" ]]; then
  ./float_mode.sh
elif [[ "$option_chosed" =~ "2" ]]; then
  ./ch_waybar.sh
fi
