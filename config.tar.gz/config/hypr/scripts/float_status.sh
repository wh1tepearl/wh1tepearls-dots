#!/bin/bash

HYPRCONF="$HOME/.config/hypr/hyprland.conf"
FLOAT_STRING="windowrulev2 = float, class:.*" # Строка, которую мы ищем в конфиге

if grep -q "$FLOAT_STRING" "$HYPRCONF"; then
  echo "+=+" # Иконка, когда float mode (или правило для него) найдено
else
  echo "[]=" # Другая иконка, когда строка не найдена
fi
