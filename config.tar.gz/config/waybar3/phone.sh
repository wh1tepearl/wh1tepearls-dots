scrcpy -K
