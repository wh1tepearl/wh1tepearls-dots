#!/bin/bash

read -p "Are you sure you want to poweroff? (y, N) " answer

if [[ "$answer" =~ ^[Yy]$ ]]; then
    echo "Powering off..."
    poweroff
else
    echo "Operation canceled."
fi
