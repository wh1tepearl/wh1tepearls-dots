pkill swaync
swaync
